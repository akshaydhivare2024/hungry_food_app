<template>
  <div class="q-pa-md">
    <h2 class="text-weight-bold">Welcome to Hungry !!!</h2>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>where your cravings meet culinary excellence. We are more than just a restaurant; we are an experience crafted
        to
        tantalize your taste buds and leave you craving for more. At Hungry, we believe that a great meal is not just
        about food; it's about creating unforgettable moments and sharing them with your loved ones.</p>
    </transition>

    <h5 class="text-weight-bold">Our Story</h5>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>Hungry was founded with a passion for exceptional food and a desire to create a warm and inviting dining
        atmosphere. Our journey began with a simple idea: to serve delicious, freshly prepared dishes that reflect our
        love for flavors from around the world. Over the years, we have evolved and expanded, but our commitment to
        quality and customer satisfaction has remained unwavering.</p>
    </transition>

    <h5 class="text-weight-bold">Our Cuisine</h5>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>Our menu is a culinary journey through a variety of cuisines, carefully curated to cater to diverse palates.
        From
        sizzling steaks to savory pasta, from spicy curries to mouthwatering desserts, our chefs take pride in using
        only
        the finest ingredients to bring you the most delightful dining experience possible. Whether you're a fan of
        classic comfort food or craving bold, innovative flavors, Hungry has something to satisfy every appetite.</p>
    </transition>

    <h5 class="text-weight-bold">Our Team</h5>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>Behind every delicious dish at Hungry is a team of passionate individuals dedicated to delivering excellence.
        From our talented chefs who infuse creativity into every recipe, to our attentive waitstaff who ensure your
        dining
        experience is memorable, we work together to make your visit exceptional. We believe that great food is a result
        of a collaborative effort, and we're proud to have a team that shares our commitment to excellence.</p>
    </transition>

    <h5 class="text-weight-bold">Our Values
    </h5>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>At Hungry, we value :</p>
    </transition>

    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <ul class="bg-white q-pa-md">
        <li>Quality : We source the finest ingredients to create dishes that are consistently delicious.
        </li>
        <li>Hospitality : We strive to provide warm, welcoming, and attentive service to make you feel at home.</li>
        <li>Innovation : We embrace creativity and constantly explore new culinary horizons to surprise and delight our
          guests.
        </li>
        <li>
          Community : We believe in giving back to the community that has supported us, and we actively engage in
          charitable initiatives.</li>
      </ul>
    </transition>

    <h5 class="text-weight-bold">Your Experience</h5>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>Your satisfaction is our top priority. Whether you're celebrating a special occasion, enjoying a casual meal
        with
        friends, or simply indulging your taste buds, we want every visit to Hungry to be memorable. Our commitment to
        excellence extends beyond the kitchen; it's about creating a dining experience that keeps you coming back for
        more.</p>
    </transition>
    <transition appear enter-active-class="animated slower zoomIn" leave-active-class="animated zoomIn">

      <p>Thank you for choosing Hungry as your dining destination. We look forward to serving you and making every meal
        a
        delightful experience.</p>
    </transition>

  </div>
</template>

<script setup>

</script>

<style scoped></style>
