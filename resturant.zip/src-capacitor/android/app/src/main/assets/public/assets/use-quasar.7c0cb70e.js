import{i as a,an as r}from"./index.039091f6.js";function u(){return a(r)}export{u};
