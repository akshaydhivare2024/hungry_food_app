import{b as e}from"./index.039091f6.js";const u={dark:{type:Boolean,default:null}};function o(a,r){return e(()=>a.dark===null?r.dark.isActive:a.dark)}export{o as a,u};
