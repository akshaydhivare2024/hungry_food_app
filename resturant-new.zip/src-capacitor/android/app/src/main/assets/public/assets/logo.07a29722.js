var s="assets/logo.978c1381.png";export{s as _};
